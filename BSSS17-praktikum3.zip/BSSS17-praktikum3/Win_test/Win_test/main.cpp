#include <cstdio>
#include <iostream>

#include "processing_unit.h"

int main()
{
	
	processing_unit pu;

	pu.work();
    
    return 0;
}