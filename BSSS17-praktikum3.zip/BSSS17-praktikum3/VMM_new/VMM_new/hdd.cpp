#include "hdd.h"



hdd::hdd()
{
}


hdd::~hdd()
{
	bytes.clear();
}
