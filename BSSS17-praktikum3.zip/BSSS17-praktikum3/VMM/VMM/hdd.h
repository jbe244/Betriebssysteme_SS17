#pragma once

#include "byte.h"
#include <vector>

class hdd
{
public:
	hdd();
	~hdd();


	std::vector<byte*> bytes;

};

