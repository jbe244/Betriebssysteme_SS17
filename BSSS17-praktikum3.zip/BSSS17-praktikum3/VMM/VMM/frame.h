#pragma once

#include "page.h"

class page;

class frame
{
public:
	frame();
	~frame();

	page* Page = nullptr;


};

