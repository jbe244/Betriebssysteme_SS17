#include "frame.h"



frame::frame()
{

	

}


frame::~frame()
{
}
