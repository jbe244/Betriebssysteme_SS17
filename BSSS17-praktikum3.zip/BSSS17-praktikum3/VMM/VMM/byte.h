#pragma once

#include <random>

class byte
{
public:
	byte();
	byte(byte*);
	byte(int);
	~byte();

	int value;
	

};

