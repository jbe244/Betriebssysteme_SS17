#include "page.h"



page::page()
{
}


page::~page()
{
}
