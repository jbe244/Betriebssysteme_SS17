
#ifndef REPORTER_H
#define REPORTER_H


class reporter
{
public:
	reporter();
	~reporter();
	void report();
};

#endif