#ifndef SCHEDULER_ALGORYTHM_1_H
#define SCHEDULER_ALGORYTHM_1_H

#include "scheduler.h"
class scheduler_algorythm_1 :
	public scheduler
{
public:
	scheduler_algorythm_1();
	~scheduler_algorythm_1();
	void schedule();
};

#endif