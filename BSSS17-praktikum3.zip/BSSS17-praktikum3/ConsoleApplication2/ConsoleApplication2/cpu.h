#pragma once
class cpu
{
};

