#include "Rahmen.h"



Rahmen::Rahmen()
{
    
}


Rahmen::~Rahmen()
{
}