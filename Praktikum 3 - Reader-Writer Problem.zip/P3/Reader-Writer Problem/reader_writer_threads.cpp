#include <iostream>			
#include <thread>			
#include <chrono>			

#include <mutex>

#include "database.h"
#include "reader_writer_threads.h"

//std::mutex dbMutex;		// mutex for database -> Aufgabe 1, Reader bevorzugt
std::mutex writerMutex;     //Aufgabe 2 -> Faire Lösung
std::mutex readerMutex;     //Aufgabe 2 -> Faire Lösung
std::mutex readercounterMutex; 
int readerCounter = 0;

// The writer thread
void writer( int writerID, int numSeconds ) {

	std::cout << "Writer " << writerID << " starting..." << std::endl;

	int	tests = 0; 
	auto startTime = std::chrono::steady_clock::now();
	std::chrono::seconds maxTime( numSeconds ); 
	while ( ( std::chrono::steady_clock::now() - startTime ) < maxTime ) {
		
//		dbMutex.lock();		// lock database
                readerMutex.lock();     //stellt Anfrage an die Reader auf Zugriff mithilfe von writerMutex.lock())
		writerMutex.lock();     
                readerMutex.unlock();     //Anfrage wurde entgegengenommen -> Zugriff gewährt
                
		bool result = theDatabase.write( writerID );
		++tests;

                writerMutex.unlock();
//		dbMutex.unlock();	// unlock database
		
		// sleep a while...
		int numSeconds2sleep = randomInt( 3 ); // i.e. either 0, 1 or 2 
		std::chrono::seconds randomSeconds( numSeconds2sleep );
		std::cout << "WRITER " << writerID 
			      << " Finished test " << tests
			      << ", result = " << result
			      << ", sleeping " << numSeconds2sleep
			      << " seconds " << std::endl;
		if ( numSeconds2sleep ) std::this_thread::sleep_for ( randomSeconds ); 
		
	} // repeat until time used is up
	
	std::cout << "WRITER " << writerID 
		      << "Finished. Returning after " << tests 
		      << " tests." << std::endl;

} // end writer function

// The reader thread
void reader( int readerID, int numSeconds ) {
	
	std::cout << "Reader " << readerID << " starting..." << std::endl;
	
	int	tests=0;
	auto startTime = std::chrono::steady_clock::now();
	std::chrono::seconds maxTime( numSeconds ); 
	while ( ( std::chrono::steady_clock::now() - startTime ) < maxTime ) {

                readerMutex.lock();
		readercounterMutex.lock();				// lock readerCounter
		readerCounter++;			// increase readerCounter
		if(readerCounter == 1) {	// if this is the first reader thread
//			dbMutex.lock();			// -> lock database
                        writerMutex.lock();
		}
		readercounterMutex.unlock();			// unlock readerCounter
                readerMutex.unlock();
		
		bool result = theDatabase.read( readerID );
		++tests;

               
		readercounterMutex.lock();				// lock readerCounter
		readerCounter--;			// decrease readerCounter
		if(readerCounter == 0) {	// if this was the last reader thread
//			dbMutex.unlock();		// -> unlock database
                        writerMutex.unlock();
		}
		readercounterMutex.unlock();			// unlock readerCounter
		
		
		// sleep a while...
		int numSeconds2sleep = randomInt( 3 ); // i.e. either 0, 1 or 2 
		std::chrono::seconds randomSeconds( numSeconds2sleep );
		std::cout << "READER " << readerID 
			      << " Finished test " << tests
			      << ", result = " << result
			      << ", sleeping " << numSeconds2sleep
			      << " seconds " << std::endl;
		if ( numSeconds2sleep ) std::this_thread::sleep_for ( randomSeconds ); 

	} // repeat until time is used up
	
	std::cout << "READER " << readerID 
		      << "Finished. Returning after " << tests 
		      << " tests." << std::endl;

} // end reader function