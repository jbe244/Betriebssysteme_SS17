#include <chrono>	

class stopwatch
{
	
private:
	
	typedef std::chrono::steady_clock		clock;
	
	long long int		numberOfMeasurements { 0 }; 
	clock::duration		totalTimeMeasured { 0 };
	clock::time_point	startPoint;
	
public:
	
	stopwatch() { 
		startMeasuring(); // just to be sure lastPoint has a meaningful value
	};

	
	void startMeasuring( ) 		{ 
		startPoint = clock::now(); 
	}
	
	std::chrono::nanoseconds takeMeasurement( ) 	{ 
		totalTimeMeasured += ( clock::now() - startPoint  );
		numberOfMeasurements++;
		return( totalTimeMeasured );
	}; 

	// return value is in seconds
	double averageMeasurement( ) const { 
		 // protect against division by zero
		if ( 0 == numberOfMeasurements ) return( 0.0 );
	
		std::chrono::duration< double >		totalSeconds( totalTimeMeasured );
		return ( totalSeconds.count() / (double)numberOfMeasurements );
	};

	long long int count( ) const { return numberOfMeasurements; }

}; 
