/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   header.h
 * Author: debian
 *
 * Created on May 24, 2017, 4:37 AM
 */

#ifndef HEADER_H
#define HEADER_H

#include <unistd.h>
#include <stdlib.h>
#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <string>
#include <fstream>
#include <signal.h>
#include <stdexcept>
#include <vector>
#include <cstdint>
#include <algorithm>

using namespace std;

#endif /* HEADER_H */

