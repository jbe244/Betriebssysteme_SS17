#include"Page.h"


Page::Page(const bitset<6>& virtual_adress, const size_t& content)
:m_virtual_adress(virtual_adress), m_content(content)
{

}